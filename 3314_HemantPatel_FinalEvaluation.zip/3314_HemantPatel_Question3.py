str_1 = "Nithin and his mom went to park last friday " \
        "Nittin's mom observed that the weather was too cool " \
        "If we reverse the number 1331 then we also we get 1331"
pallin = []
for i in str_1:
    if i == i[::-1]:
        pallin.append(i)

print(pallin)




