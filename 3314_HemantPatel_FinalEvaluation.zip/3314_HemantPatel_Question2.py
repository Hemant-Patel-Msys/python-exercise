class Number:
    def __init__(self):
        self.sum = 0
        pass
    def add(self,num):
        self.num = num
        sum = 0
        while num > 0:
            rem = num % 10
            sum = sum + rem
            num = num // 10
        sum1 = 0
        while sum > 0:
            rem1 = sum % 10
            sum1 = sum1 + rem1
            sum = sum // 10

        return sum1




n = Number()
print(n.add(68))



